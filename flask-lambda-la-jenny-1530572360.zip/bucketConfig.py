UPLOAD_BUCKET = 'flasklambdalab-dev-uploads-a209b368'
THUMB_BUCKET = 'flasklambdalab-dev-thumbnails-a261bdec'
